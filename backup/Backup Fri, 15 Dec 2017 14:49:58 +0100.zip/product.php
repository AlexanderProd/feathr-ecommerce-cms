<?php session_start(); ?>
<!DOCTYPE html>
<html lang="de">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title>s1ck.one</title>
  <meta name="description" content="">
  <meta name="author" content="H2 E-Commerce">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  <link rel="stylesheet" href="css/style.css">

  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/favicon.png">

   <?php

    $productNumber = $_GET['product']; // Get Variable from parent Page to define Product Number
    include 'csvData.php';
    $array = getCsvData("data.csv");
    array_unshift($array, "0");
    unset($array[0]);
    $products = sizeof($array);

   ?>

</head>
<body>

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <!-- Header -->
  <header class="container">
    <div class="row">
      <div class="twelve columns center" style="margin-top: 15%">
        <a href="index.php"><img src="images/logo.png" /></a>
        <p><a href="index.php">Zurück</a></p>
      </div>
    </div>
  </header>

  <!-- Product -->
  <div class="container" style="margin-top: 5%;">
    <div class="row">
      <div class="one-half column center">
        <img src="<?php echo $array[$productNumber]['ImagePath']?>" style="width: 100%;"/>
      </div>
      <div class="one-half column">
        <h4><?php echo $array[$productNumber]['Product']?></h4>
        <h5><?php echo $array[$productNumber]['Price']?> EUR</h5>
        <p><?php echo $array[$productNumber]['Description']?></p>
        <!--<form action="/your-server-side-code" method="POST">
          <script
            src="https://checkout.stripe.com/checkout.js" class="stripe-button"
            data-key="pk_live_VfvgrARx0xy51AdZZwS4FgPU"
            data-amount="<?php echo str_replace(",","",$array[$productNumber][1]); ?>"
            data-name="s1ck.one"
            data-description="<?php echo $array[$productNumber][0]?>"
            data-image="https://stripe.com/img/documentation/checkout/marketplace.png"
            data-locale="auto"
            data-billing-address="true"
            data-shipping-address="true"
            data-zip-code="true">
          </script>
        </form>-->
        <a class="button" href="cart.php">In den Warenkorb</a>
        <?php $_SESSION["productToCart"] = $productNumber; ?>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="container">
    <div class="row">
      <div class="twelve columns center">
        <p>&copy; 2017 <a href="http://h2-ecommerce.com">H2 E-Commerce</a> <a href="#">Impressum</a></p>
      </div>
    </div>
  </footer>

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>
</html>
