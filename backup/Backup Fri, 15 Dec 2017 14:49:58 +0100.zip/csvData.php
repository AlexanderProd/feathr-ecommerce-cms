<?php
function getCsvData($filePath) {
  $array = $fields = array(); $i = 0;
  $handle = @fopen($filePath, "r");
  if ($handle) {
    while (($row = fgetcsv($handle, 4096, "|")) !== false) {
        if (empty($fields)) {
            $fields = $row;
            continue;
        }
        foreach ($row as $k=>$value) {
            $array[$i][$fields[$k]] = $value;
        }
        $i++;
    }
    if (!feof($handle)) {
        echo "Error: unexpected fgets() fail\n";
    }
    fclose($handle);
  }

  $products = sizeof($array);
  return $array;

  /*echo "<pre>";
  print_r($array);
  echo "</pre>";
  echo "<br/>";
  echo $products;*/
  }
?>
