<!DOCTYPE html>
<html lang="de">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title>s1ck.one</title>
  <meta name="description" content="">
  <meta name="author" content="H2 E-Commerce">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  <link rel="stylesheet" href="css/style.css">

  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/favicon.png">

   <?php

    #$productNumber = 1;
    $productNumber = $_GET['product'];
    $array = explode("\n", file_get_contents("data.txt"));
    array_unshift($array, "0");
    unset($array[0]);
    array_pop($array);
    $products = sizeof($array);

    for ($i=1; $i < $products+1; $i++) {
      $data = explode("|", $array[$i]);
      $array[$i] = $data;
    }

   ?>

</head>
<body>

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <!-- Header -->
  <header class="container">
    <div class="row">
      <div class="twelve columns center" style="margin-top: 15%">
        <h2>s1ck.one</h2>
        <p><a href="index.php">Zurück</a></p>
      </div>
    </div>
  </header>

  <!-- Product -->
  <div class="container" style="margin-top: 5%;">
    <div class="row">
      <div class="one-half column center">
        <img src="<?php echo $array[$productNumber][2]?>" style="width: 100%;"/>
      </div>
      <div class="one-half column">
        <h4><?php echo $array[$productNumber][0]?></h4>
        <h5><?php echo $array[$productNumber][1]?> EUR</h5>
        <p><?php echo $array[$productNumber][4]?></p>
        <form action="/your-server-side-code" method="POST">
          <script
            src="https://checkout.stripe.com/checkout.js" class="stripe-button"
            data-key="pk_live_VfvgrARx0xy51AdZZwS4FgPU"
            data-amount="<?php echo str_replace(",","",$array[$productNumber][1]); ?>"
            data-name="s1ck.one"
            data-description="<?php echo $array[$productNumber][0]?>"
            data-image="https://stripe.com/img/documentation/checkout/marketplace.png"
            data-locale="auto"
            data-billing-address="true"
            data-shipping-address="true"
            data-zip-code="true">
          </script>
        </form>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="container">
    <div class="row">
      <div class="twelve columns center">
        <p>&copy; 2017 <a href="http://h2-ecommerce.com">H2 E-Commerce</a> <a href="#">Impressum</a></p>
      </div>
    </div>
  </footer>

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>
</html>
