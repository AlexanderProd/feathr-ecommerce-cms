<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title>s1ck.one</title>
  <meta name="description" content="">
  <meta name="author" content="H2 E-Commerce">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  <link rel="stylesheet" href="css/style.css">

  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/favicon.png">

  <?php

   $productNumber = $_SESSION["productToCart"];
   include 'csvData.php';
   $array = getCsvData("data.csv");
   #array_unshift($array, "0"); // Fügt den Wert 0 an den Anfang des Arrays an
   #unset($array[0]); // Entfernt den ersten Wert das Arrays
   $products = sizeof($array);

   $priceInCents = str_replace(",", "", $array[$productNumber]['Price']);
   $priceWithDots = str_replace(",", ".", $array[$productNumber]['Price']);

  ?>

</head>

<body>
  <div class="container" style="margin-top: 5%;">
    <div class="row">
      <div class="one-half column center">
        <?php echo $array[$productNumber]['Product']?><br>
        <?php echo $array[$productNumber]['Price'],' ',$array[$productNumber]['Currency']?><br>


        <!-- Stripe Checkout -->
        <?php require_once('./config.php'); ?>
        <form action="charge.php" method="post">
          <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                  data-key="<?php echo $stripe['publishable_key']; ?>"
                  data-amount="<?php echo $priceInCents?>"
                  data-name="s1ck.one"
                  data-description="<?php echo $array[$productNumber]['Product']?>"
                  data-image="https://stripe.com/img/documentation/checkout/marketplace.png"
                  data-locale="auto"
                  data-zip-code="true"
                  data-currency="<?php echo $array[$productNumber]['Currency']?>">
          </script>
        </form>

        <!-- PayPal Express Checkout Button -->
        <script src="https://www.paypalobjects.com/api/checkout.js"></script>
        <div id="paypal-button"></div>

          <script>
            paypal.Button.render({
              env: 'production', // Or 'sandbox',

              client: {
                    sandbox:    'Ad41WVGJahkW5XBg0IN8KLzQH8HeZHvJ0s_jJHuN_rUPrDwtE0FSRIkRa2Zr3GPmE60C3cCZIXLANZah',
                    production: 'ATEp_qCeSiRl4g9Tj8sIdx5oOaQrOrKO439IG7ou42uW-N1OzRNLukV_jOPizB-9lm-CxyewfJ8cXOiD'
              },

              commit: true, // Show a 'Pay Now' button

              style: {
                color: 'gold',
                size: 'medium'
              },

              payment: function(data, actions) {
                return actions.payment.create({
                        payment: {
                            transactions: [
                                {
                                    amount: { total: '<?php echo $priceWithDots ?>', currency: '<?php echo $array[$productNumber]['Currency']?>' }
                                }
                            ]
                        }
                });
              },

              onAuthorize: function(data, actions) {
                return actions.payment.execute().then(function(payment) {
                  window.open ('index.php','_self',false)
                });
              },

              onCancel: function(data, actions) {
                /*
                 * Buyer cancelled the payment
                 */
              },

              onError: function(err) {
                /*
                 * An error occurred during the transaction
                 */
              }
            }, '#paypal-button');
          </script>
      </div>

      <div class="one-half column center">
        xyz
      </div>
    </div>
  </div>

</body>
</html>
