<?php session_start(); ?>

<?php

 $productNumber = $_SESSION["productToCart"];
 include 'csvData.php';
 $array = getCsvData("data.csv");
 array_unshift($array, "0"); // Fügt den Wert 0 an den Anfang des Arrays an
 unset($array[0]); // Entfernt den ersten Wert das Arrays
 $products = sizeof($array);

?>

<?php echo $array[$productNumber]['Product']?><br>
<?php echo $array[$productNumber]['Price']?><br>
