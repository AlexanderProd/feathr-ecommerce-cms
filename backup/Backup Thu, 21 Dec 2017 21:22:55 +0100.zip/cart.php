<?php session_start(); ?>

<html>
<body>

<?php

 $productNumber = $_SESSION["productToCart"];
 include 'csvData.php';
 $array = getCsvData("data.csv");
 array_unshift($array, "0"); // Fügt den Wert 0 an den Anfang des Arrays an
 unset($array[0]); // Entfernt den ersten Wert das Arrays
 $products = sizeof($array);

?>

<?php echo $array[$productNumber]['Product']?><br>
<?php echo $array[$productNumber]['Price']?><br>
<?php $priceInCents = str_replace(",", "", $array[$productNumber]['Price']);?>

<form action="/your-server-side-code" method="POST">
<script
  src="https://checkout.stripe.com/checkout.js" class="stripe-button"
  data-key="pk_test_Gmbhao56LeFZAs7MKivhIXXL"
  data-amount="<?php echo $priceInCents ?>"
  data-name="Stripe.com"
  data-description="<?php echo $array[$productNumber]['Product']?>"
  data-image="https://stripe.com/img/documentation/checkout/marketplace.png"
  data-locale="auto"
  data-zip-code="true">
</script>
</form>

</body>
</html>
